SUPLA FOR ITEAD SONOFF WiFi Smart Switch + DS18B20
v2.0

boot_v1.5.bin--------->0x00000
sonoff_ds18b20_user1.1024.new.2.bin---->0x01000

RX (GPIO3) - OneWire DAT

BAUDRATE: 115200
Flash Size: 1MByte
Flash speed: 40Mhz
SPI Mode: DIO

// CFG MODE ----------------------------------------

To bring the device into configuration
mode, press and hold button for at least 5 sec. When in configuration mode,
the device goes into Access Point mode.

In order to enter or change the settings, you need to:

- Sign in at https://cloud.supla.org (registration is free of charge)
- Connect to WiFi called „SUPLA-ESP8266” from any computer with a wireless network card and Internet browser.
- Open access page: http://192.168.4.1
- Enter user name and password to the WiFi through which the device will get Internet access.
- Enter Server address, Location ID and Location Password, which will be provided once you sign in at cloud.supla.org

