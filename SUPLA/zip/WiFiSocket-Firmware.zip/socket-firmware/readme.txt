SUPLA WIFI SOCKET

wifisocket_eagle.flash.bin-------->0x00000
wifisocket_eagle.irom0text.bin---->0x40000

PORT SETTINGS:

[CHANNEL0] RELAY GPIO4
BUTTON GPIO5
RGB LED 
    - RED GPIO13
    - GREEN GPIO12
    - BLUE GPIO14

[CHANNEL1] DS18B20 Sensor GPIO2

//--------------------------------------------------------------------------
//--------------------------------------------------------------------------
//--------------------------------------------------------------------------

SUPLA WIFI SOCKET (GPIO 5<->4)

wifisocket_54_eagle.flash.bin-------->0x00000
wifisocket_54_eagle.irom0text.bin---->0x40000

PORT SETTINGS:

[CHANNEL0] RELAY GPIO5
BUTTON GPIO4
RGB LED
    - RED GPIO13
    - GREEN GPIO12
    - BLUE GPIO14

[CHANNEL1] DS18B20 Sensor GPIO2


//--------------------------------------------------------------------------
//--------------------------------------------------------------------------
//--------------------------------------------------------------------------

SUPLA WIFI SOCKET FOR ESP01

wifisocket_esp01_eagle.flash.bin-------->0x00000
wifisocket_esp01_eagle.irom0text.bin---->0x40000

PORT SETTINGS:

[CHANNEL0] RELAY GPIO0
BUTTON GPIO2


Manuals:
-EN-
http://www.instructables.com/id/ESP8266-and-Relay-Control-Using-Smartphone/
https://www.supla.org/download/wifisocket-manual-en.pdf
-PL-
http://majsterkowo.pl/esp8266-i-sterowanie-przekaznikiem-przy-pomocy-smartfona/
https://www.supla.org/download/wifisocket-manual-pl.pdf

WiFi-Socket Prototype presentation video:
https://www.youtube.com/watch?v=LR-tzCnBZvc
