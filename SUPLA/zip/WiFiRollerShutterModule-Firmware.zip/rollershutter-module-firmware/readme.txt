SUPLA WIFI ROLLER SHUTTER MODULE

rs_module_eagle.flash.bin-------->0x00000
rs_module_eagle.irom0text.bin---->0x40000

PORT SETTINGS:

  [CHANNEL0] RELAY1 GPIO4
  [CHANNEL0] RELAY2 GPIO13
  CFG BUTTON GPIO5

  LED 
      - GREEN GPIO12
      - BLUE GPIO14

  [CHANNEL1] INPUT_PORT1 GPIO12

  GPIO12 operate in two modes. In and Out (In - INPUT, Out - LED)

  [CHANNEL2] DS18B20 Sensor GPIO2

// ---------------------------------------------
// ---------------------------------------------
// ---------------------------------------------

rs_module_wroom_eagle.flash.bin-------->0x00000
rs_module_wroom_eagle.irom0text.bin---->0x40000

WROOM PORT SETTINGS:

  [CHANNEL0] RELAY1 GPIO4
  [CHANNEL0] RELAY2 GPIO14
  CFG BUTTON GPIO13

  LED
      - GREEN GPIO5
      - BLUE GPIO12

  [CHANNEL1] INPUT_PORT1 GPIO5

  GPIO5 operate in two modes. In and Out (In - INPUT, Out - LED)

  [CHANNEL2] DS18B20 Sensor GPIO2


